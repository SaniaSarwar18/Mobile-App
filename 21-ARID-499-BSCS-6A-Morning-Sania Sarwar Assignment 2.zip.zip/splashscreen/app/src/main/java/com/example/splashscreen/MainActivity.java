package com.example.temp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import com.example.temp.databinding.ActivitySplashscreenBinding;

public class Splashscreen extends AppCompatActivity {
    private ActivitySplashscreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashscreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.umbrellafly.setAnimation(R.raw.umbrella);
        binding.umbrellafly.playAnimation();

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                binding.sunspawn.setAnimation(R.raw.sun);
                binding.sunspawn.playAnimation();
            }
        }, 2500);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(Splashscreen.this, MainActivity.class));
                finish();
            }
        }, 5000);
    }
}
